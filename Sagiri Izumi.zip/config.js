//Sc by Xyro base Clara MD
//Di Tulis Ulang VynaChan
//Buat lu semua yang jual sc ini gua ga bakal share lagi!

import { watchFile, unwatchFile } from 'fs'
import chalk from 'chalk'
import { fileURLToPath } from 'url'
const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)

// Owner
global.owner = [
['6285829238321', '美Keyraa', true] //Ganti aja
]
global.mods = []
global.prems = []
// Info
global.nomorwa = '6285829238321' //Ganti
global.packname = '© Sticker by'
global.author = 'Yaremiku-MD'
global.namebot = 'Yaremiku - MD'
global.wm = '© Yaremiku MD By KeyraaChan'
global.stickpack = '© Sticker by'
global.stickauth = 'Yaremiku-MD'
// Link Sosmed
global.sig = '-'
global.sgh = '-'
global.sgc = '-'
// Donasi
global.psaweria = '085829238321'
global.ptrakterr = '085829238321'
global.povo = '085829238321'
// Info Wait
global.wait = '⏳ Proses...'
global.eror = 'Terjadi Kesalahan Coba Lagi Nanti!'
global.multiplier = 69 
// Apikey
global.xyro = 'cz3I4THpML'
// Catatan : Jika Mau Work Fiturnya
// Masukan Apikeymu
// Gapunya Apikey? Ya Daftar
// Website: https://api.xyroinee.xyz
// Daftar Ke Website Tersebut Untuk
// Mendapatkan Apikey Kamu
global.APIs = {
    xyro: "https://api.xyroinee.xyz",
}

/*Apikey*/
global.APIKeys = {
    "https://api.xyroinee.xyz": "cz3I4THpML",
}

let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
  unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  import(`${file}?update=${Date.now()}`)
})
let handler = async (m, { conn }) => {
let fotonya = 'https://telegra.ph/file/f5742305fdf673f056e91.jpg'
let sewa = `
╔━━━『 *NSWF Menu* 』
┃ ⬡ .hollolewd
┃ ⬡ .sideoppai
┃ ⬡ .animefeets
┃ ⬡ .animebooty
┃ ⬡ .animethighss
┃ ⬡ .animearmpits
┃ ⬡ .lewdanimegirls
┃ ⬡ .biganimetiddies
┃ ⬡ .animeblowjob
┃ ⬡ .gangbang
┃ ⬡ .hinata
┃ ⬡ .lewd
┃ ⬡ .masturbation
┃ ⬡ .ometv
┃ ⬡ .orgy
┃ ⬡ .paptt
╚━━━━━━━━━━━━✧
 _2023 © VynaaMD_
`
conn.reply(m.chat, sewa, m)
}
handler.help = ['nsfwmenu']
handler.tags = ['main']
handler.command = /^(nsfwmenu)$/i

export default handler